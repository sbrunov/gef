/*
   SwingWT
   Copyright(c)2003-2007, R. Rawson-Tetley

   For more information on distributing and using this program, please
   see the accompanying "COPYING" file.

   Contact me by electronic mail: bobintetley@users.sourceforge.net


*/


package swingwt.awt;

import org.eclipse.swt.widgets.*;
import org.eclipse.swt.*;

import swingwtx.swing.*;

import java.util.*;

/**
 * Any component that can contain other components.
 * This class maps the Swing layouts/placements to SWT
 */
public class Container extends Component {

    /** The SWT peer this container represents */
    public org.eclipse.swt.widgets.Composite composite = null;

    /** The layout manager being used to position child components */
    protected LayoutManager layout = null;

    /** Cache of components waiting to be laid out */
    protected Vector comps = new Vector();

    protected Vector containerListeners = new Vector();
    
    public Dimension getMinimumSize() { 
        return (layout==null) ? super.getMinimumSize() : layout.minimumLayoutSize(this);
    }

    public Dimension minimumSize() { return getMinimumSize(); }
    public Dimension preferredSize() { return getPreferredSize(); }

    public Dimension getPreferredSize() { 
        return (layout==null) ? super.getPreferredSize() : layout.preferredLayoutSize(this);
    }

    public Dimension getMaximumSize() { 
        return (layout instanceof LayoutManager2) ? 
            ((LayoutManager2)layout).maximumLayoutSize(this) :
            super.getMaximumSize();
    }

    public void addContainerListener(swingwt.awt.event.ContainerListener l) {
        containerListeners.add(l);
    }

    public void removeContainerListener(swingwt.awt.event.ContainerListener l) {
        containerListeners.remove(l);
    }

    public Component add(Component c) {
        return doAdd(c);
    }
    
    public Component add(Component c, int index) {
        return add(c);    
    }

    /** Actually does the hard work of adding something to a container */
    public Component doAdd(final Component c) {

        if (c == null) return null;
        final Container me = this;

        // Don't add it to the cache again if this component is already cached
        // - this stops us adding the same component twice.
        if (comps.indexOf(c) == -1) {
            comps.add(c);
        }
        
        // Cache us with the child component - this is just so that
        // the hierarchy is visible before the peers are realised
        c.parent = this;        
        
        if (!SwingWTUtils.isSWTControlAvailable(composite)) return c;

        // Register the comonent with the layout if needed
        addComponentToLayout(c);

        // Ensure that the setSwingWTParent calls are on the dispatch
        // thread as they go down - object creation should always be
        // on this thread
        SwingUtilities.invokeSync(new Runnable() {
            public void run() {

                try {
                    c.setSwingWTParent(me);
                    c.setCachedProperties();
                    c.registerEvents();
                    processContainerEvent(new swingwt.awt.event.ContainerEvent(me, swingwt.awt.event.ContainerEvent.COMPONENT_ADDED, c));
                }
                catch (Exception e) {
                    e.printStackTrace();
                }

                queuedValidate();

            }
        });
        return c;
    }

    protected void processEvent(AWTEvent e) {
        // Can't think of any reason for this to be here other than compile compat
    }
    
    protected void processContainerEvent(swingwt.awt.event.ContainerEvent e) {
        if (containerListeners.size() == 0) return;
        for (int i = 0; i < containerListeners.size(); i++) {
            if (e.getID() == swingwt.awt.event.ContainerEvent.COMPONENT_ADDED)
                ((swingwt.awt.event.ContainerListener) containerListeners.get(i)).componentAdded(e);
            else
                ((swingwt.awt.event.ContainerListener) containerListeners.get(i)).componentRemoved(e);
        }
    }

    /**
     * Adds an existing component to the layout manager
     */
    public void addComponentToLayout(Component c) {
        if (layout != null) {
            if (layout instanceof LayoutManager2)  {
                ((LayoutManager2)layout).addLayoutComponent(c, c.layoutModifier);
            }
            else
                layout.addLayoutComponent(c.getName(), c);
        }
    }

    /** Forces laying out of this container's child components again. */
    public void invalidate() {
        final Container me = this;
        if (SwingWTUtils.isSWTControlAvailable(composite))
            if (layout != null)
                SwingUtilities.invokeSync(new Runnable() {
                    public void run() {
                        layout.layoutContainer(me);
                    }
                });
    }

    /** Forces laying out of this container's child components again. */
    public void doLayout() { invalidate(); }
    /** Forces laying out of this container's child components again. */
    public void validate() { invalidate(); }
    //Stubbed
    protected void validateTree() {}
    /** Forces laying out of this container's child components again. */
    public void revalidate() { invalidate(); }

    /**
     * Attempts to ensure that a request to layout a container is only
     * done once whilst adding many components to a container. What we do is
     * basically set a flag to say we need to relayout the container, and if further
     * requests come in the next 50ms, we ignore them. This should really take the heat
     * off the CPU whilst building containers with many objects.
     *
     * Since this generally gets called as we work down the tree doing setSwingWTParent
     * calls, that thread will basically block with no invalidation until all
     * components have been added (what we want) - this is just horribly complex to
     * get your head round, but it works :-)
     *
     * @author Robin Rawson-Tetley
     */
    public void queuedValidate() {
        if (queuedValidateRequest) return; // Already waiting - don't do anything
         queuedValidateRequest = true;
         SwingUtilities.invokeIn(new Runnable() {
             public void run() {
                 invalidate();
                 queuedValidateRequest = false;
             }
         }, 1);
    }
    protected boolean queuedValidateRequest = false;

    /**
     * Addition for layouts requiring object based modifiers
     */
    public void add(swingwt.awt.Component c, Object layoutModifier) {
        if (c == null) return;
        c.layoutModifier = layoutModifier;

        if (layoutModifier instanceof String)
            layout.addLayoutComponent((String)layoutModifier, c);

        doAdd(c);
    }
    
    public void add(swingwt.awt.Component c, Object layoutModifier, int index) {
        add(c, layoutModifier);    
    }

    public Component add(String name, swingwt.awt.Component c) {
        add(c,name);
        return c;
    }

    public void dispose() {

        // Dispose of all child components (and their components)
        if (comps != null) {
            for (int i = 0; i < comps.size(); i++) {
                try {
                    ((Component) comps.get(i)).dispose();
                }
                catch (Exception e) {}
            }
            // Ditch the cache
            comps.removeAllElements();
        }

        if (peer != null) super.dispose();
        
	composite = null;
	peer = null;
    }

    /**
     * Removes a component from the the container
     * by destroying the peer.
     */
    public void remove(swingwt.awt.Component c) {
        comps.remove(c);
        if (layout != null) layout.removeLayoutComponent(c);
        c.componentOnlyDispose();
        c.setComponentRemoved();
        processContainerEvent(new swingwt.awt.event.ContainerEvent(this, swingwt.awt.event.ContainerEvent.COMPONENT_REMOVED, c));
        invalidate();
    }

    public void remove(int index) {
        Component c = (Component) comps.get(index);
        remove(c);
    }

    public void removeAll() {
        for (int i = 0; i < comps.size(); i++) {
            Component c = (Component) comps.get(i);
	    remove(c);
        }
        comps.removeAllElements();
        invalidate();
    }

    /** Removes a cached component only */
    public void removeComponentFromCache(Component c) {
        comps.remove(c);
    }

    /** Returns the layout used by this container */
    public LayoutManager getLayout() {
            return layout;
    }

    /**
     * I'm totally re-writing this method.  No longer
     * will it only mirror the layouts.  From now on,
     * it will actually use the layout managers to layout
     * the component, not the mirrored SWT layouts.
     * Two big advantages with this approach.  (a) It
     * allows custom layout managers.  (b) It means
     * less work since we don't have to port anything.
     * (yea!)
     *
     * @author Daniel Spiewak
     */
    public void setLayout(LayoutManager l) {
        setLayoutImpl(l);
    }

    /**
     * The actual code that handles assignment of the
     * layout manager.
     *
     * Separated out as setLayout will often get
     * subclassed and my head will explode if I don't
     * do something like this :-)
     */
    protected void setLayoutImpl(LayoutManager l) {
        layout = l;

        if (composite == null)
                return;

        SwingUtilities.invokeSync(new Runnable() {
            public void run() {

                // we don't want an SWT layout since we will control the layout ourselves
                composite.setLayout(null);

                // add a resize listener to let us know when to invalidate the layout
                composite.addListener(SWT.Resize, new Listener() {
                        public void handleEvent(org.eclipse.swt.widgets.Event e) {
                                invalidate();
                        }
                });

            }
        });
    }

    /** Returns the SWT peer being used for this container */
    public org.eclipse.swt.widgets.Composite getComposite() {
        return composite;
    }

    public Container getParent() {
        return parent;
    }

    /** Called when this gets added. We can set layouts and things
     *  then if necessary. Note that subclasses are responsible
     *  for creating the actual peer and setting the protected
     *  "composite" variable */
    public void setSwingWTParent(swingwt.awt.Container parent) throws Exception {

        if (layout != null)
            setLayoutImpl(layout);

        if (comps.size() > 0) {
            Object[] obs = comps.toArray();
            for (int i = 0; i < obs.length; i++) {
                Component c = (Component) obs[i];
                doAdd(c);
            }
        }
    }

    public ComponentOrientation getComponentOrientation() {
            return ComponentOrientation.getOrientation(Locale.getDefault());
    }

    public Insets getInsets() {
        return new Insets(0,0,0,0);
    }

    public int getComponentCount() {
        return comps.size();
    }

    public Component getComponent(int i) {
    	if (i < comps.size())
            return (Component) comps.get(i);
    	else
    		return null;
    }

    public Component[] getComponents() {
        Object[] comp = comps.toArray();
        Component[] cps = new Component[comp.length];
        for (int i = 0; i < comp.length; i++) {
            cps[i] = (Component) comp[i];
        }
        return cps;
    }

    /**
     * Useful for debugging purposes. Shows this container and
     * all it's children.
     */
    public void debug_showContainmentTree() {
        System.out.println("Containment Tree: ====================");
        System.out.println(getClass().getName());
        xdebug_showChildren(this, 1);
    }
    private void xdebug_showChildren(Container c, int level) {
        final String SPACE = "                   ";
        for (int i = 0; i < c.comps.size(); i++) {
            Component d =  (Component) c.comps.get(i);
            System.out.println(SPACE.substring(0, level) + d.getClass().getName());
            if (d instanceof Container)
                xdebug_showChildren((Container) d, level+1);
        }
    }
    //TODO: implement this
    // public Set<AWTKeyStroke> getFocusTraversalKeys(int id)  1.5
    public Set getFocusTraversalKeys(int id)
    {
    	return null;
    	
    }
    //TODO: implement this
    // setFocusTraversalKeys(int id, Set<? extends AWTKeyStroke> keystrokes)     1.5
    public void getFocusTraversalKeys(int id, Set keyStrokes)
    {
    	
    	
    }
    public void setFocusTraversalPolicy(FocusTraversalPolicy policy)
    {
    	
    	
    }
    public  FocusTraversalPolicy getFocusTraversalPolicy()
    {
    	return null;
    }

}
