/*
   SwingWT
   Copyright(c)2003-2007, R. Rawson-Tetley

   For more information on distributing and using this program, please
   see the accompanying "COPYING" file.

   Contact me by electronic mail: bobintetley@users.sourceforge.net

*/

package swingwt.awt;

import swingwt.awt.geom.*;

public class Polygon implements Shape {

    public int npoints;
    public int xpoints[];
    public int ypoints[];
    protected Rectangle bounds;
    
    public Polygon() {
    }
    public Polygon(int xpoints[], int ypoints[], int npoints) {
    }
    public void reset() {
	npoints = 0;
	bounds = null;
    }
    public void invalidate() {
	bounds = null;
    }
    public void translate(int deltaX, int deltaY) {
	// FIXME: Implement
    }	
    public void addPoint(int x, int y) {
	// FIXME: Implement
    }
    public Rectangle getBounds() {
	return getBoundingBox();
    }
    public Rectangle getBoundingBox() {
	return null;
    }
    public boolean contains(Point p) {
	return contains(p.x, p.y);
    }
    public boolean contains(int x, int y) {
	return contains((double) x, (double) y);
    }
    public boolean inside(int x, int y) {
	return contains((double) x, (double) y);
    }
    public Rectangle2D getBounds2D() {
	return getBounds();
    }
    public boolean contains(double x, double y) {
        // FIXME: Implement
	return false;
    }
    
    public boolean contains(Point2D p) {
        // FIXME: Implement
	return false;
    }
    public boolean intersects(double x, double y, double w, double h) {
        // FIXME: Implement
	return false;
    }
    public boolean intersects(Rectangle2D r) {
	return intersects(r.getX(), r.getY(), r.getWidth(), r.getHeight());
    }
    public boolean contains(double x, double y, double w, double h) {
	// FIXME: Implement
	return false;
    }
    public boolean contains(Rectangle2D r) {
	return contains(r.getX(), r.getY(), r.getWidth(), r.getHeight());
    }
    public PathIterator getPathIterator(AffineTransform at) {
	return null;
    }
    public PathIterator getPathIterator(AffineTransform at, double flatness) {
	return null;
    }
}
