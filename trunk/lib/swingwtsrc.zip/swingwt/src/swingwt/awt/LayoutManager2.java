/*
   SwingWT
   Copyright(c)2003-2007, R. Rawson-Tetley

   For more information on distributing and using this program, please
   see the accompanying "COPYING" file.

   Contact me by electronic mail: bobintetley@users.sourceforge.net
 
 
 */
package swingwt.awt;

/**
 * @author Daniel Spiewak
 */
public interface LayoutManager2 extends LayoutManager {

	void addLayoutComponent(Component comp, Object constraints);
	public Dimension maximumLayoutSize(Container target);
	public float getLayoutAlignmentX(Container target);
	public float getLayoutAlignmentY(Container target);
	public void invalidateLayout(Container target);
}
