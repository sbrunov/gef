/*
   SwingWT
   Copyright(c)2003-2007, Tomer Bartletz
 
   For more information on distributing and using this program, please
   see the accompanying "COPYING" file.
 
   Contact me by electronic mail: tomerb@users.sourceforge.net

 */

package swingwt.awt.event;

public class MouseMotionAdapter implements MouseMotionListener {
    
    public void mouseDragged(MouseEvent e) {}    
    public void mouseMoved(MouseEvent e) {}
    
}
