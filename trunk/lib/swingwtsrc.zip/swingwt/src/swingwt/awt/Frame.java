/*
   SwingWT
   Copyright(c)2003-2007, R. Rawson-Tetley

   For more information on distributing and using this program, please
   see the accompanying "COPYING" file.

   Contact me by electronic mail: bobintetley@users.sourceforge.net


*/

package swingwt.awt;

import org.eclipse.swt.SWT;

import swingwtx.swing.SwingUtilities;
import swingwtx.swing.SwingWTUtils;

/**
 * note: MenuContainer methods are actually implemented in Window, contrary to AWT/Swing.
 * Still, add the interface here.
 */
public class Frame extends Window implements MenuContainer {
    
    public final static int NORMAL = 0;
    public final static int ICONIFIED = 1;
    public final static int MAXIMIZED_HORIZ = 2;
    public final static int MAXIMIZED_VERT = 4;
    public final static int MAXIMIZED_BOTH = MAXIMIZED_HORIZ | MAXIMIZED_VERT;
    
    protected boolean isResizable = true;
    protected int state = NORMAL;
    protected boolean isMax = false;
    
    private int intRetval;
    
    public Frame() {
        this("");
    }
    public Frame(GraphicsConfiguration gc) { this(); }
    public Frame(String title) { super((Frame)null); setTitle(title); }
    
    protected int getSWTFrameType()
    {
        int SWTFrameType = SWT.SHELL_TRIM;
        SWTFrameType |= isResizable ? SWT.RESIZE : 0;
        return SWTFrameType;
    }
    
    public void setResizable(boolean b) { this.isResizable = b; }
    public boolean isResizable() { return isResizable; }
    
    public void remove(MenuComponent menuComponent) { pMenuBar.remove(menuComponent); }
    public void setExtendedState(final int state) {
        this.state = state;
        if (SwingWTUtils.isSWTControlAvailable(peer)) {
	        SwingUtilities.invokeSync(new Runnable() {
	           public void run() {
	                if ( ((state & MAXIMIZED_BOTH) > 0) ||
	                    ((state & MAXIMIZED_HORIZ) > 0) ||
	                    ((state & MAXIMIZED_VERT) > 0) ) {
	                    peer.setMaximized(true);
	                    isMax = true;
	                }
	                else {
	                    peer.setMaximized(false);
	                    isMax = false;
	                }
	
	                if ((state & ICONIFIED) > 0) {
	                    peer.setMinimized(true);
	                    isIcon = true;
	                }
	                else {
	                    peer.setMinimized(false);
	                    isIcon = false;
	                }
	           }
	        });
        }
    }
    public int getExtendedState() {
        if (SwingWTUtils.isSWTControlAvailable(peer)) {
	        SwingUtilities.invokeSync(new Runnable() {
	            public void run() {
		            if (peer.getMaximized())
		                intRetval = MAXIMIZED_BOTH;
		            else if (peer.getMinimized())
		                intRetval = ICONIFIED;
		            else
		                intRetval = NORMAL;
	            }
	        });
        }
        else intRetval = state;
        return intRetval;
    }
    public void setUndecorated(boolean undecorated){}
    
}
