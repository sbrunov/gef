/*
   SwingWT
   Copyright(c)2003-2007, Tomer Barletz

   For more information on distributing and using this program, please
   see the accompanying "COPYING" file.

   Contact me by electronic mail: tomerb@users.sourceforge.net
*/

package swingwt.awt.datatransfer;

public class DataFlavor {
  
  private String humanPresentableName;
  public static DataFlavor stringFlavor = new DataFlavor("application-x-serialized-java-object");

  /** NOT IMPLEMENTED */
  public DataFlavor(String mimetype) {
  }
  
  public String getHumanPresentableName() { return humanPresentableName; }

  public void setHumanPresentableName(String humanPresentableName) {
    this.humanPresentableName = humanPresentableName;
  }

  

}
