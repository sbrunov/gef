package swingwt.awt;

/**
 * @author Daniel Spiewak
 */
public class ImageCapabilities {

	/**
	 * @param b
	 */
	public ImageCapabilities(boolean b) {
	}

}


