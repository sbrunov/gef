package swingwt.awt;

import swingwt.awt.image.*;

// TODO: Implement this.
// for now it is here for Swingwt wrapper func.
public class Robot {
    public Robot() throws AWTException {
    }
    public Robot(GraphicsDevice screen) throws AWTException 
    {
    }
    public synchronized void mouseMove(int x, int y) 
    {
    }
    public synchronized void mousePress(int buttons) 
    {
    }
    public synchronized void mouseRelease(int buttons) 
    {
    }
    public synchronized void mouseWheel(int wheelAmt) 
    {
    }
    public synchronized void keyPress(int keycode) 
    {
    }
    public synchronized void keyRelease(int keycode) 
    {
    }
    public synchronized Color getPixelColor(int x, int y) 
    {
	return null;
    }
    public synchronized BufferedImage createScreenCapture(Rectangle screenRect) 
    {
    	return null;
    }
    public synchronized boolean isAutoWaitForIdle() {
	return false;
    }
    public synchronized void setAutoWaitForIdle(boolean isOn) {
    }
    public synchronized int getAutoDelay() {
	return 0;
    }
    public synchronized void setAutoDelay(int ms) {
    }
    public synchronized void delay(int ms) {
    }
    public synchronized void waitForIdle() {
    }
    public synchronized String toString() {
	return getClass().getName();
    }
}
