package swingwt.awt.image;

public class IndexColorModel extends ColorModel {
	public IndexColorModel(){
		// default to 8 bits per pixel
		super(8);
	}
}
