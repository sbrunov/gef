package swingwt.awt.image;

public class SampleModel {

public SampleModel createCompatibleSampleModel(int w, int h) {
	return null;
}

public DataBuffer createDataBuffer() {
	return null;
}

public SampleModel createSubsetSampleModel(int[] bands) {
	return null;
}

public Object getDataElements(int x, int y, int w, int h, Object obj, DataBuffer data) {
	return null;
}

public Object getDataElements(int x, int y, Object obj, DataBuffer data) {
	return null;
}

public int getNumDataElements() {
	return 0;
}

public double[] getPixel(int x, int y, double[] dArray, DataBuffer data) {
	return null;
}

public float[] getPixel(int x, int y, float[] fArray, DataBuffer data) {
	return null;
}

public int[] getPixel(int x, int y, int[] iArray, DataBuffer data) {
	return null;
}

public double[] getPixels(int x, int y, int w, int h, double[] dArray, DataBuffer data) {
	return null;
}

public float[] getPixels(int x, int y, int w, int h, float[] fArray, DataBuffer data) {
	return null;
}

public int[] getPixels(int x, int y, int w, int h, int[] iArray, DataBuffer data) {
	return null;
}

public int getSample(int x, int y, int b, DataBuffer data) {
	return 0;
}

public double getSampleDouble(int x, int y, int b, DataBuffer data) {
	return 0;
}

public float getSampleFloat(int x, int y, int b, DataBuffer data) {
	return 0;
}

public double[] getSamples(int x, int y, int w, int h, int b, double[] dArray, DataBuffer data) {
	return null;
}

public float[] getSamples(int x, int y, int w, int h, int b, float[] fArray, DataBuffer data) {
	return null;
}

public int[] getSamples(int x, int y, int w, int h, int b, int[] iArray, DataBuffer data) {
	return null;
}

public int[] getSampleSize() {
	return null;
}

public int getSampleSize(int band) {
	return 0;
}

public int getTransferType() {
	return 0;
}

public void setDataElements(int x, int y, int w, int h, Object obj, DataBuffer data) {

}

public void setDataElements(int x, int y, Object obj, DataBuffer data) {
}

public void setPixel(int x, int y, double[] dArray, DataBuffer data) {
}

public void setPixel(int x, int y, float[] fArray, DataBuffer data) {
}

public void setPixel(int x, int y, int[] iArray, DataBuffer data) {
}

public void setPixels(int x, int y, int w, int h, double[] dArray, DataBuffer data) {
}

public void setPixels(int x, int y, int w, int h, float[] fArray, DataBuffer data) {
}

public void setPixels(int x, int y, int w, int h, int[] iArray, DataBuffer data) {
}

public void setSample(int x, int y, int b, double s, DataBuffer data) {
}

public void setSample(int x, int y, int b, float s, DataBuffer data) {
}

public void setSample(int x, int y, int b, int s, DataBuffer data) {
}

public void setSamples(int x, int y, int w, int h, int b, double[] dArray, DataBuffer data) {
}

public void setSamples(int x, int y, int w, int h, int b, float[] fArray, DataBuffer data) {
}

public void setSamples(int x, int y, int w, int h, int b, int[] iArray, DataBuffer data) {
}

}
