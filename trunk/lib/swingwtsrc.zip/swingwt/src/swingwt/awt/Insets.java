/*
   SwingWT
   Copyright(c)2003-2007, R. Rawson-Tetley

   For more information on distributing and using this program, please
   see the accompanying "COPYING" file.

   Contact me by electronic mail: bobintetley@users.sourceforge.net
 
*/

package swingwt.awt;


public class Insets implements Cloneable {

    public Insets() { }
    public Insets(int top, int left, int bottom, int right) {
        this.top = top;
        this.left = left;
        this.bottom = bottom;
        this.right = right;
    }
  
    public int top;
    public int left;
    public int bottom;
    public int right;
    
    public Object clone() {
    	try {
    		return super.clone();
    	} catch (Exception e) {
    		// never gonna happen
    	}
    	
    	return null;
    }
}

