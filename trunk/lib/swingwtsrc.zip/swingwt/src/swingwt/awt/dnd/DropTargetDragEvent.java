/*
   SwingWT
   Copyright(c)2003-2007, R. Rawson-Tetley
 
   For more information on distributing and using this program, please
   see the accompanying "COPYING" file.
 
   Contact me by electronic mail: bobintetley@users.sourceforge.net
 
 */
package swingwt.awt.dnd;

import swingwt.awt.Point;

/** @author Laurent Martell */
public class DropTargetDragEvent extends DropTargetEvent {

    public DropTargetDragEvent(DropTargetContext context,
                               Point cursorLocation,
                               int dropAction,
                               int srcActions)
    {
        super(context);
    }
}
