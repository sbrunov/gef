/*
   SwingWT
   Copyright(c)2003-2007, R. Rawson-Tetley

   For more information on distributing and using this program, please
   see the accompanying "COPYING" file.

   Contact me by electronic mail: bobintetley@users.sourceforge.net


 */


package swingwtx.swing;

import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Composite;

import swingwt.awt.Color;

public class JPanel extends JComponent {

    /** The panel's peer */
    protected Composite ppeer = null;
    protected boolean opaque = true;

    /** Creates a new JPanel */
    public JPanel() {this(false);}
    /** Creates a new JPanel with the specified buffering scheme
     *  @param isDoubleBuffered  Whether or not to double buffer paint callbacks
     */
    public JPanel(boolean isDoubleBuffered) { this(new swingwt.awt.FlowLayout(), false); }
    /** Creates a new JPanel with the specified layout
     *  @param layout The layout manager to use
     */
    public JPanel(swingwt.awt.LayoutManager layout) { 
    	setLayout(layout); 
    }

    /** Creates a new JPanel with the specified layout and buffering scheme
     *  @param layout The layout manager to use
     *  @param isDoubleBuffered Whether or not to double buffer paint callbacks
     */
    public JPanel(swingwt.awt.LayoutManager layout, boolean isDoubleBuffered) { 
    	setLayout(layout); 
    }
    /** Creates a new JPanel with the specified layout
     *  @param layout The layout manager to use
     */
    public JPanel(swingwt.awt.LayoutManager2 layout) { 
    	setLayout(layout);
    }
    
    /** Creates a new JPanel with the specified layout and buffering scheme
     *  @param layout The layout manager to use
     *  @param isDoubleBuffered Whether or not to double buffer paint callbacks
     */
    public JPanel(swingwt.awt.LayoutManager2 layout, boolean isDoubleBuffered) { 
    	setLayout(layout);
    }

    /** Overriden to calculate non-realised
     *  preferred size.
     */
    protected swingwt.awt.Dimension calculatePreferredSize() {
        // Default 300x200
        swingwt.awt.Dimension size = new swingwt.awt.Dimension(300, 200);
        setSize(size);
        return size;
    }
    
    /** Callback for when this is added to a Container to create the
     *  peer and load cached values.
     */
    public void setSwingWTParent(swingwt.awt.Container parent) throws Exception {
        descendantHasPeer = true;
        
        boolean usePlatformBorder = 
            (border instanceof swingwtx.swing.border.EtchedBorder) ||
            (border instanceof swingwtx.swing.border.LineBorder) ||
            (border instanceof swingwtx.swing.border.BevelBorder) ||
            (border instanceof swingwtx.swing.border.SoftBevelBorder);
        
        ppeer = new Composite(parent.getComposite(), usePlatformBorder ? SWT.BORDER : SWT.NONE );
        peer = ppeer;
        composite = ppeer;
        this.parent = parent;
        super.setSwingWTParent(parent);
    }

    /** Sets the border for the Panel
     *  @param b The new border
     */
    public void setBorder(swingwtx.swing.border.Border b) {
        border = b;
    }

    /**
     *  Return how large this panel would like to be if it's inside a ScrollPane, rather
     *  than how large it actually is. This is used by layout managers when determining
     *  how to layout the components. If you need the actual size of a JPanel in
     *  a scroll pane, use getPeerSize() which always return the
     *  correct values.
     */
    public swingwt.awt.Dimension getSize() {
        if (parent instanceof JScrollPane)
            return getPreferredSize();
        else
            return super.getSize();
    }
    /** Returns the width of the peer
     *  @return the width
     */
    public int getWidth() { return getSize().width; }
    /** Returns the height of the peer
     *  @return the height
     */
    public int getHeight() { return getSize().height; }

}
