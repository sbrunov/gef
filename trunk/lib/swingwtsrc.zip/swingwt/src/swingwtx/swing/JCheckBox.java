/*
   SwingWT
   Copyright(c)2003-2007, R. Rawson-Tetley

   For more information on distributing and using this program, please
   see the accompanying "COPYING" file.

   Contact me by electronic mail: bobintetley@users.sourceforge.net

*/


package swingwtx.swing;

import org.eclipse.swt.widgets.*;
import org.eclipse.swt.*;

import swingwt.awt.event.*;

import java.util.*;

public class JCheckBox extends swingwtx.swing.AbstractButton implements ButtonModel, SwingConstants {
    
    /** boolean thread safe accessor */
    private boolean bRetVal;

    /** AWT uses Checkboxes for radio buttons as well **/
    private boolean isAWTRadio = false;
    
    public JCheckBox() {this(""); }
    public JCheckBox(String text) { this(text, false); }
    public JCheckBox(String text, Icon icon) { this(text, false); }
    public JCheckBox(String text, boolean selected) { pText = text; pSelection = selected; setModel(this);  showMnemonic();}
    /** This constructor is used for AWT CheckboxGroup support **/
    public JCheckBox(String text, boolean selected, ButtonGroup bg) { pText = text; pSelection = selected; isAWTRadio = true; setModel(this);  showMnemonic();}
    
    
    /**
     *  Sends mouse events to component listeners 
     *  Overriden from Component to handle ItemEvents
     */
    public void processMouseEvent(MouseEvent e) {
        Iterator i = mouseListeners.iterator();
        while (i.hasNext()) {
            MouseListener ml = (MouseListener) i.next();
            int eventID = e.getID();
            if (eventID == MouseEvent.MOUSE_CLICKED) {ml.mouseClicked(e); processItemEvent(); }
            if (eventID == MouseEvent.MOUSE_ENTERED) ml.mouseEntered(e);
            if (eventID == MouseEvent.MOUSE_EXITED) ml.mouseExited(e);
            if (eventID == MouseEvent.MOUSE_PRESSED) ml.mousePressed(e);
            if (eventID == MouseEvent.MOUSE_RELEASED) ml.mouseReleased(e);
        }
    }
    
    /**
     * Sends KeyEvents to component listeners
     * Overriden from Component to handle ItemEvents
     */
    public void processKeyEvent(KeyEvent e) {
        Iterator i = keyListeners.iterator();
        while (i.hasNext()) {
            KeyListener ml = (KeyListener) i.next();
            if (e.eventID == KeyEvent.PRESSED) { ml.keyTyped(e); processItemEvent(); }
            if (e.eventID == KeyEvent.RELEASED) ml.keyReleased(e);
            if (e.eventID == KeyEvent.PRESSED) ml.keyPressed(e);
        }  
    }

    /** Overriden to calculate non-realised
     *  preferred size.
     */
    protected swingwt.awt.Dimension calculatePreferredSize() {
        // Use the text height/width + 6 pixels for
        // borders and an extra 8 pixels for the checkbox itself.
        swingwt.awt.Dimension size = new swingwt.awt.Dimension( 
            SwingWTUtils.getRenderStringWidth(pText) + 6, 
            SwingWTUtils.getRenderStringHeight(pText) + 6);
        setSize(size);
        return size;
    }
    
    /**
     * Once a parent component receives an "add" call for a child, this being
     * the child, this should be called to tell us to instantiate the peer
     * and load in any cached properties.
     */
    public void setSwingWTParent(swingwt.awt.Container parent) throws Exception {
        descendantHasPeer = true;
        if (isAWTRadio) {
            ppeer = new Button(parent.getComposite(), SWT.RADIO);
        } else {
            ppeer = new Button(parent.getComposite(), SWT.CHECK);
        }
        ppeer.setText(pText);
        ppeer.setSelection(pSelection);
        ppeer.setAlignment( SwingWTUtils.translateSwingAlignmentConstant(pVAlign) | 
            SwingWTUtils.translateSwingAlignmentConstant(pHAlign) );
        peer = ppeer;
        this.parent = parent;
    }
    
    public boolean isSelected() { 
        bRetVal = false;
        SwingUtilities.invokeSync(new Runnable() {
            public void run() {
                if (!SwingWTUtils.isSWTControlAvailable(ppeer)) bRetVal = pSelection; else bRetVal = ppeer.getSelection();
            }
        });
        return bRetVal;
    }
        
    public void setSelected(final boolean b) { 
        SwingUtilities.invokeSync(new Runnable() {
            public void run() {
                if (SwingWTUtils.isSWTControlAvailable(ppeer)) ppeer.setSelection(b); else pSelection = b; 
            }
        });
    }
    
    public Object[] getSelectedObjects() {
        return null;
    }
    
    public int getMnemonic() {
        return 0;
    }
    
    public boolean isArmed() {
        return false;
    }
    
    public boolean isPressed() {
        return false;
    }
    
    public boolean isRollover() {
        return false;
    }
    
    public void setArmed(boolean b) {
    }
    
    public void setPressed(boolean b) {
    }
    
    public void setRollover(boolean b) {
    }
    
}
