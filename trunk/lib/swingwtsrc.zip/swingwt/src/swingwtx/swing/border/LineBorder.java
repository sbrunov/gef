/*
   SwingWT
   Copyright(c)2003-2007, R. Rawson-Tetley

   For more information on distributing and using this program, please
   see the accompanying "COPYING" file.

   Contact me by electronic mail: bobintetley@users.sourceforge.net

*/

package swingwtx.swing.border;

import swingwt.awt.*;

public class LineBorder extends AbstractBorder implements Border {
    public static Border createBlackLineBorder() { return new LineBorder(Color.BLACK, 1); }
    public static Border createGrayLineBorder() { return new LineBorder(Color.GRAY, 1); }
    public LineBorder(Color color) {}
    public LineBorder(Color color, int thickness)  {}
    public LineBorder(Color color, int thickness, boolean roundedCorners)  {}
}
