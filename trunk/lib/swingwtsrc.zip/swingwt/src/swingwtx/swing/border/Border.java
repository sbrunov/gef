/*
   SwingWT
   Copyright(c)2003-2007, R. Rawson-Tetley

   For more information on distributing and using this program, please
   see the accompanying "COPYING" file.

   Contact me by electronic mail: bobintetley@users.sourceforge.net

*/

package swingwtx.swing.border;

public interface Border {
    void paintBorder(swingwt.awt.Component c, swingwt.awt.Graphics g, int x, int y, int width, int height);
    swingwt.awt.Insets getBorderInsets(swingwt.awt.Component c);
    boolean isBorderOpaque();
}
