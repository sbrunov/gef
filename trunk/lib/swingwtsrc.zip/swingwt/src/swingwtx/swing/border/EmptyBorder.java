/*
   SwingWT
   Copyright(c)2003-2007, R. Rawson-Tetley

   For more information on distributing and using this program, please
   see the accompanying "COPYING" file.

   Contact me by electronic mail: bobintetley@users.sourceforge.net


*/

package swingwtx.swing.border;

import swingwt.awt.*;

public class EmptyBorder extends AbstractBorder implements Border {
    protected int left, right, top, bottom;

    public EmptyBorder(Insets borderInsets) {
        this(borderInsets.top, borderInsets.left, borderInsets.bottom, borderInsets.right);
    }
    public EmptyBorder(int top, int left, int bottom, int right) {
        this.top = top;
        this.left = left;
        this.bottom = bottom;
        this.right = right;
    }

    public Insets getBorderInsets(Component c) { return getBorderInsets(); }
    public Insets getBorderInsets() { return new Insets(top, left, bottom, right); }

    public Insets getBorderInsets(Component c, Insets insets) {
        insets.top = top;
        insets.left = left;
        insets.bottom = bottom;
        insets.right = right;
        return insets;
    }
}
