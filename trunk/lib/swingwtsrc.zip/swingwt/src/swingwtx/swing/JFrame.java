/*
   SwingWT
   Copyright(c)2003-2007, R. Rawson-Tetley

   For more information on distributing and using this program, please
   see the accompanying "COPYING" file.

   Contact me by electronic mail: bobintetley@users.sourceforge.net


*/


package swingwtx.swing;

import swingwt.awt.*;

public class JFrame extends swingwt.awt.Frame implements WindowConstants, RootPaneContainer {


	public static final int EXIT_ON_CLOSE = WindowConstants.EXIT_ON_CLOSE;
    protected int closeOperation = WindowConstants.DISPOSE_ON_CLOSE;
    
    
    public JFrame() { super();}
    public JFrame(String title) {super(title); }
    public JFrame(GraphicsConfiguration gc) { super(gc); }
    
    public void setCachedProperties() {
        super.setCachedProperties();
        setExtendedState(state);
    }
    /** Handy for layout problems. Toggles the window between
     *  max/norm according to what is set and guarantees 
     *  relayout of components
     */
    public void toggleWindowState() {
        SwingUtilities.invokeSync(new Runnable() {
            public void run() {
               if (isMax) {
                   peer.setMaximized(false);
                   peer.setMaximized(true);
               }
               else
               {
                   peer.setMaximized(true);
                   peer.setMaximized(false);
               }
            }
        });
    }
    
    public int getDefaultCloseOperation() { 
        return closeOperation;
    }
    
    public void setDefaultCloseOperation(int operation) {
        closeOperation = operation;
    }
    
    public Container getContentPane() {
        return rootPane.getContentPane();
    }
    
    public Component getGlassPane() {
        return rootPane.getGlassPane();
    }
    
    public JLayeredPane getLayeredPane() {
        return rootPane.getLayeredPane();
    }
    
    public JRootPane getRootPane() {
        return rootPane;
    }
    
    public void setContentPane(Container contentPane) {
        rootPane.setContentPane(contentPane);
    }
    
    public void setGlassPane(Component glassPane) {
        rootPane.setGlassPane(glassPane);
    }
    
    public void setLayeredPane(JLayeredPane layeredPane) {
        rootPane.setLayeredPane(layeredPane);
    }
    
    public void registerWindowEvents() {
        
        // Overriden here so we can manage default close operations.
        
        peer.addShellListener(new org.eclipse.swt.events.ShellListener() {
            public void shellActivated(org.eclipse.swt.events.ShellEvent e) {
                processWindowEvent(swingwt.awt.event.WindowEvent.WINDOW_ACTIVATED);
            }
            public void shellClosed(org.eclipse.swt.events.ShellEvent e) {
                isClosed = true;
                processWindowEvent(swingwt.awt.event.WindowEvent.WINDOW_CLOSING);
                processWindowEvent(swingwt.awt.event.WindowEvent.WINDOW_CLOSED);
                // See what's set for the default close operation and handle it
                switch (closeOperation) {
                    case WindowConstants.DISPOSE_ON_CLOSE: e.doit = true; SwingWTUtils.decrementWindowReferences(); break;
                    case WindowConstants.DO_NOTHING_ON_CLOSE: e.doit = false; break;
                    case WindowConstants.EXIT_ON_CLOSE: e.doit = true; SwingWTUtils.decrementWindowReferences(); System.exit(0); break;
                    case WindowConstants.HIDE_ON_CLOSE: e.doit = false; peer.setVisible(false); break;
                }
            }
            public void shellDeactivated(org.eclipse.swt.events.ShellEvent e) {
                processWindowEvent(swingwt.awt.event.WindowEvent.WINDOW_DEACTIVATED);
            }
            public void shellDeiconified(org.eclipse.swt.events.ShellEvent e) {
                processWindowEvent(swingwt.awt.event.WindowEvent.WINDOW_DEICONIFIED);
            }
            public void shellIconified(org.eclipse.swt.events.ShellEvent e) {
                processWindowEvent(swingwt.awt.event.WindowEvent.WINDOW_ICONIFIED);
            }
        });
    }
    
}
