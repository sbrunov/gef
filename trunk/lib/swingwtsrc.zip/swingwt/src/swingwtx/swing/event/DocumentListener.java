/*
   SwingWT
   Copyright(c)2003-2007, R. Rawson-Tetley

   For more information on distributing and using this program, please
   see the accompanying "COPYING" file.

   Contact me by electronic mail: bobintetley@users.sourceforge.net

*/
package swingwtx.swing.event;

public interface DocumentListener extends java.util.EventListener {
    public void insertUpdate(DocumentEvent e);
    public void removeUpdate(DocumentEvent e);
    public void changedUpdate(DocumentEvent e);
}
