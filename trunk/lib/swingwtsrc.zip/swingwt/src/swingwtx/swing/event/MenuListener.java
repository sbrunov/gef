/*
   SwingWT
   Copyright(c)2003-2007, R. Rawson-Tetley

   For more information on distributing and using this program, please
   see the accompanying "COPYING" file.

   Contact me by electronic mail: bobintetley@users.sourceforge.net


*/

package swingwtx.swing.event;

public interface MenuListener extends java.util.EventListener {
    void menuSelected(MenuEvent e);
    void menuDeselected(MenuEvent e);
    void menuCanceled(MenuEvent e);
}

