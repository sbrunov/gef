/*
   SwingWT
   Copyright(c)2003-2007, R. Rawson-Tetley
 
   For more information on distributing and using this program, please
   see the accompanying "COPYING" file.
 
   Contact me by electronic mail: bobintetley@users.sourceforge.net

 
 */

package swingwtx.swing;

import java.util.*;
import swingwtx.swing.event.*;

public interface CellEditor {

    public Object getCellEditorValue();
    public boolean isCellEditable(EventObject anEvent);
    public boolean shouldSelectCell(EventObject anEvent);
    public boolean stopCellEditing();
    public void cancelCellEditing();
    public void addCellEditorListener(CellEditorListener l);
    public void removeCellEditorListener(CellEditorListener l);
}

