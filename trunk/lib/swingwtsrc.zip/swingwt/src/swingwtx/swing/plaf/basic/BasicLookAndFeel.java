package swingwtx.swing.plaf.basic;


import java.io.*;

import swingwtx.swing.*;

public abstract class BasicLookAndFeel extends LookAndFeel implements Serializable
{
}
